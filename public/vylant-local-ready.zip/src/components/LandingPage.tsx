import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  Globe, 
  Cpu, 
  Users, 
  ChevronRight,
  ArrowRight,
  Check,
  Plus,
  Minus,
  Download,
  Apple,
  Bot,
  Terminal,
  Laptop,
  Smartphone,
  Sparkles
} from 'lucide-react';

interface LandingPageProps {
  onLaunch: () => void;
  onLogin: () => void;
  onSignUp: () => void;
  onSupport: () => void;
  onPrivacy: () => void;
  onTerms: () => void;
  isLoggedIn: boolean;
  onDownloadApp?: (platform?: 'mac' | 'ios' | 'android' | 'linux' | 'windows') => void;
  appDownloaded?: boolean;
}

const faqItems = [
  {
    question: "What is Vylant?",
    answer: "Vylant is a next-generation high-fidelity communication platform designed for privacy, speed, and reliability. It combines cutting-edge security with a seamless user experience across all devices."
  },
  {
    question: "Is my data truly secure?",
    answer: "Yes. Vylant uses end-to-end encryption for all messages and media. We do not store your private keys on our servers, meaning even we cannot access your conversations."
  },
  {
    question: "Can I use it on multiple devices?",
    answer: "Absolutely. Vylant syncs your encrypted data across all your authorized devices in real-time. Whether you're on a phone, tablet, or desktop, your conversations go with you."
  },
  {
    question: "What makes Vylant different from other messaging apps?",
    answer: "Unlike many competitors, Vylant is built with a 'privacy-first' architecture. We don't track your location, read your contact lists for advertising, or sell your data. We focus purely on delivering the best communication experience possible."
  }
];

const LandingPage: React.FC<LandingPageProps> = ({ onLaunch, onLogin, onSignUp, onSupport, onPrivacy, onTerms, isLoggedIn, onDownloadApp, appDownloaded }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const slideshowImages = [
    "https://i.imgur.com/VzOt8gf.png",
    "https://i.imgur.com/mn2Mcmo.png",
    "https://i.imgur.com/rQHQlOC.png",
    "https://i.imgur.com/h9Yp662.png",
    "https://i.imgur.com/dDYlJq5.png"
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % slideshowImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slideshowImages.length]);

  return (
    <div id="top" className="min-h-screen bg-[#030303] text-white font-sans selection:bg-cyan-500/30 overflow-x-hidden relative">
      {/* Background Ambient Glows */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-fuchsia-600/10 blur-[120px] rounded-full opacity-40" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-600/10 blur-[100px] rounded-full opacity-40" />
        <div className="absolute top-[20%] left-[10%] w-[30%] h-[30%] bg-blue-600/10 blur-[150px] rounded-full opacity-30" />
      </div>

      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-6">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => document.getElementById('top')?.scrollIntoView({ behavior: 'smooth' })}>
          <img 
            src="https://i.imgur.com/H3OS5zA.png" 
            alt="Vylant Logo" 
            className="w-10 h-10 object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        
        <div className="flex items-center gap-4">
          
          {!isLoggedIn ? (
            <>
              <button 
                onClick={onLogin}
                className="px-4 py-2 text-white/70 hover:text-white text-sm font-medium transition-colors"
              >
                Login
              </button>
              <button 
                onClick={onSignUp}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-500 hover:shadow-[0_0_25px_rgba(37,99,235,0.4)] transition-all transform hover:scale-105 active:scale-95"
              >
                Join Now
              </button>
            </>
          ) : (
            <button 
              onClick={onLaunch}
              className="px-6 py-2.5 bg-white text-black rounded-xl text-sm font-bold hover:bg-neutral-200 transition-all transform hover:scale-105 active:scale-95"
            >
              Launch App
            </button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-8 pt-44 pb-32">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Side Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-8xl md:text-9xl font-bold tracking-tighter mb-4 flex items-baseline gap-4 text-white">
              <span>Vylant</span>
            </h1>
            
            <div className="flex items-center gap-0 mb-8">
              <span className="text-2xl md:text-3xl font-medium text-white/40">Powered by</span>
              <img 
                src="https://i.imgur.com/obW6gta.png" 
                alt="T0AI Logo" 
                className="h-8 md:h-10 w-auto object-contain ml-[-2px]"
                referrerPolicy="no-referrer"
              />
            </div>

            <h2 className="text-xl md:text-2xl font-medium text-white/80 mb-6 tracking-tight">
              The future of communication starts here.
            </h2>

            <p className="text-white/40 max-w-lg mb-12 leading-relaxed text-lg">
              Experience the next evolution of messaging. Vylant combines military-grade encryption with seamless real-time syncing to ensure your private conversations stay truly private, while delivering a lightning-fast experience across all your devices.
            </p>
            
            <div className="flex items-center gap-4 flex-wrap">
              <button 
                onClick={onSignUp}
                className="px-10 py-5 bg-blue-600 text-white rounded-2xl font-bold text-xl hover:bg-blue-500 hover:shadow-[0_0_40px_rgba(37,99,235,0.3)] transition-all transform hover:scale-105 active:scale-95"
              >
                Join Now
              </button>
              {onDownloadApp && !appDownloaded && (
                <button 
                  onClick={onDownloadApp}
                  className="px-10 py-5 bg-vylant-blue/10 border border-vylant-blue/30 text-vylant-blue hover:bg-vylant-blue/20 rounded-2xl font-bold text-xl transition-all flex items-center gap-3 transform hover:scale-105 active:scale-95 cursor-pointer shadow-[0_0_30px_rgba(0,195,255,0.15)]"
                >
                  <Download size={22} />
                  <span>Download App</span>
                </button>
              )}
            </div>
          </motion.div>

          {/* Right Side Mockups */}
          <div className="relative">
            {/* Desktop Mockup */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1.1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative z-10 rounded-[2.5rem] p-3 bg-white/5 border border-white/10 backdrop-blur-sm shadow-2xl shadow-black/50"
            >
              <div className="aspect-[16/10] bg-[#0c0c0c] rounded-[2rem] overflow-hidden border border-white/5 relative">
                <AnimatePresence mode="wait">
                  <motion.img 
                    key={currentImageIndex}
                    src={slideshowImages[currentImageIndex]} 
                    alt="Vylant Interface" 
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.8, ease: "easeInOut" }}
                    className="w-full h-full object-cover object-top absolute inset-0"
                    referrerPolicy="no-referrer"
                  />
                </AnimatePresence>
                
                {/* Slideshow Progress Dots */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20">
                  {slideshowImages.map((_, i) => (
                    <div 
                      key={i}
                      className={`h-1.5 rounded-full transition-all duration-500 ${
                        currentImageIndex === i ? 'w-8 bg-cyan-400' : 'w-2 bg-white/20'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Subtle Glow beneath UI */}
            <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-[80%] h-20 bg-blue-600/10 blur-[60px] rounded-full opacity-50" />
          </div>
        </div>
      </main>
      
      {/* FAQ Section */}
      <section id="faq" className="relative z-10 max-w-5xl mx-auto px-8 pb-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Frequently Asked Questions</h2>
          <p className="text-white/40 text-lg">Everything you need to know about Vylant.</p>
        </motion.div>

        <div className="space-y-4">
          {faqItems.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group"
            >
              <button
                onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                className={`w-full p-6 text-left rounded-[1.5rem] border transition-all duration-300 flex items-center justify-between ${
                  expandedFaq === i 
                    ? 'bg-white/[0.08] border-white/20' 
                    : 'bg-white/5 border-white/10 hover:bg-white/[0.08]'
                }`}
              >
                <span className="text-lg font-semibold">{item.question}</span>
                <div className={`p-1.5 rounded-lg transition-colors ${expandedFaq === i ? 'bg-cyan-500/20 text-cyan-400' : 'bg-white/5 text-white/40 group-hover:text-white'}`}>
                  {expandedFaq === i ? <Minus size={20} /> : <Plus size={20} />}
                </div>
              </button>
              
              <AnimatePresence>
                {expandedFaq === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="p-6 pt-2 text-white/60 leading-relaxed">
                      {item.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Download Section */}
      <section className="relative z-10 max-w-5xl mx-auto px-8 pb-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative text-center"
        >
          <div className="max-w-3xl mx-auto mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-vylant-blue/10 border border-vylant-blue/30 text-vylant-blue text-xs font-bold uppercase tracking-wider mb-4">
              <Sparkles size={13} /> Available Everywhere
            </div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 text-white">Get Vylant on all your devices</h2>
            <p className="text-white/50 text-base md:text-lg leading-relaxed">
              Experience ultra-fast, end-to-end encrypted communication across Mac, iPhone, Android, Linux, and Windows with zero browser clutter.
            </p>
          </div>

          {/* Platform Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 mb-10 text-left">
            {/* Mac */}
            <div 
              onClick={() => onDownloadApp?.('mac')}
              className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-vylant-blue/50 hover:bg-white/[0.08] transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-xl bg-white/10 text-white group-hover:text-vylant-blue transition-colors">
                  <Apple size={20} />
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white/10 text-white/70">macOS</span>
              </div>
              <div>
                <div className="font-bold text-sm text-white mb-0.5">Mac</div>
                <div className="text-[11px] text-white/40 leading-snug">Apple Silicon &amp; Intel</div>
              </div>
            </div>

            {/* iOS */}
            <div 
              onClick={() => onDownloadApp?.('ios')}
              className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-vylant-blue/50 hover:bg-white/[0.08] transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 group-hover:text-purple-300 transition-colors">
                  <Smartphone size={20} />
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400">iOS</span>
              </div>
              <div>
                <div className="font-bold text-sm text-white mb-0.5">iPhone / iPad</div>
                <div className="text-[11px] text-white/40 leading-snug">Home Screen WebClip</div>
              </div>
            </div>

            {/* Android */}
            <div 
              onClick={() => onDownloadApp?.('android')}
              className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-vylant-blue/50 hover:bg-white/[0.08] transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 group-hover:text-emerald-300 transition-colors">
                  <Bot size={20} />
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400">Mobile</span>
              </div>
              <div>
                <div className="font-bold text-sm text-white mb-0.5">Android</div>
                <div className="text-[11px] text-white/40 leading-snug">1-Tap WebAPK &amp; PWA</div>
              </div>
            </div>

            {/* Linux */}
            <div 
              onClick={() => onDownloadApp?.('linux')}
              className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-vylant-blue/50 hover:bg-white/[0.08] transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 group-hover:text-amber-300 transition-colors">
                  <Terminal size={20} />
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400">Linux</span>
              </div>
              <div>
                <div className="font-bold text-sm text-white mb-0.5">Linux</div>
                <div className="text-[11px] text-white/40 leading-snug">.desktop &amp; Bash Script</div>
              </div>
            </div>

            {/* Windows */}
            <div 
              onClick={() => onDownloadApp?.('windows')}
              className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-vylant-blue/50 hover:bg-white/[0.08] transition-all cursor-pointer group flex flex-col justify-between col-span-2 sm:col-span-1"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400 group-hover:text-blue-300 transition-colors">
                  <Laptop size={20} />
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">PC</span>
              </div>
              <div>
                <div className="font-bold text-sm text-white mb-0.5">Windows</div>
                <div className="text-[11px] text-white/40 leading-snug">Standalone App (.bat)</div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4">
            {onDownloadApp && (
              <button 
                onClick={() => onDownloadApp()}
                className="px-8 py-4 bg-vylant-blue text-black hover:bg-cyan-300 rounded-2xl font-black text-lg transition-all flex items-center gap-3 transform hover:scale-105 active:scale-95 cursor-pointer shadow-[0_0_30px_rgba(0,195,255,0.25)]"
              >
                <Download size={22} />
                <span>Open Download Center</span>
              </button>
            )}
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row justify-between items-center gap-8">
           <div className="flex items-center gap-3 cursor-pointer" onClick={() => document.getElementById('top')?.scrollIntoView({ behavior: 'smooth' })}>
             <img 
               src="https://i.imgur.com/H3OS5zA.png" 
               alt="Vylant Logo" 
               className="w-8 h-8 object-contain"
               referrerPolicy="no-referrer"
             />
           </div>
           
           <div className="text-white/20 font-mono text-sm tracking-[0.3em] uppercase cursor-pointer hover:text-white/40 transition-colors" onClick={() => document.getElementById('top')?.scrollIntoView({ behavior: 'smooth' })}>
             vylant.net
           </div>

           <div className="flex gap-8 text-sm font-medium text-white/40">
             <a href="#" className="hover:text-white transition-colors" onClick={(e) => { e.preventDefault(); onPrivacy(); }}>Privacy</a>
             <a href="#" className="hover:text-white transition-colors" onClick={(e) => { e.preventDefault(); onTerms(); }}>Terms</a>
             <a href="#" className="hover:text-white transition-colors" onClick={(e) => { e.preventDefault(); onSupport(); }}>Support</a>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
