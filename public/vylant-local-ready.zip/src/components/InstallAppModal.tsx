import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  X,
  Download,
  Terminal,
  Smartphone,
  Laptop,
  Apple,
  Bot,
  QrCode,
  Copy,
  Check,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Monitor,
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import {
  PLATFORMS,
  PlatformInfo,
  detectUserPlatform,
  triggerFileDownload,
  generateMacInstallerScript,
  generateMacWebloc,
  generateIOSMobileConfig,
  generateLinuxInstallerScript,
  generateLinuxDesktopEntry,
  generateAndroidHelperHtml,
  generateWindowsBat,
  generateWindowsUrlShortcut
} from '../utils/downloadHelpers';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  installPrompt: any;
  onMarkInstalled: () => void;
  initialPlatform?: 'mac' | 'ios' | 'android' | 'linux' | 'windows' | null;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  isDarkMode,
  installPrompt,
  onMarkInstalled,
  initialPlatform = null
}) => {
  const [selectedPlatform, setSelectedPlatform] = useState<'mac' | 'ios' | 'android' | 'linux' | 'windows'>('mac');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showAllPlatforms, setShowAllPlatforms] = useState<boolean>(false);
  const [downloadFeedback, setDownloadFeedback] = useState<string | null>(null);

  // Detect platform on mount or when modal opens
  useEffect(() => {
    if (isOpen) {
      const detected = initialPlatform || detectUserPlatform();
      setSelectedPlatform(detected);
    }
  }, [isOpen, initialPlatform]);

  // Generate QR Code for Mobile Scanning
  useEffect(() => {
    if (!isOpen) return;
    const url = typeof window !== 'undefined' ? (window.location.origin || window.location.href) : 'https://vylant.net';
    QRCode.toDataURL(url, {
      width: 280,
      margin: 1.5,
      color: {
        dark: '#030712',
        light: '#ffffff'
      }
    })
      .then((dataUri) => setQrDataUrl(dataUri))
      .catch((err) => console.error('QR code generation error:', err));
  }, [isOpen]);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? (window.location.origin || window.location.href) : 'https://vylant.net';

  const copyToClipboard = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2500);
    } catch (e) {
      console.warn('Copy failed:', e);
    }
  };

  const showDownloadNotice = (msg: string) => {
    setDownloadFeedback(msg);
    setTimeout(() => setDownloadFeedback(null), 3500);
  };

  // Platform-specific download triggers
  const handleDownloadMac = () => {
    triggerFileDownload(generateMacInstallerScript(currentUrl), 'Vylant-macOS-Installer.command', 'application/x-sh');
    showDownloadNotice('Downloaded Vylant-macOS-Installer.command! Double-click to install on Mac.');
    onMarkInstalled();
  };

  const handleDownloadMacWebloc = () => {
    triggerFileDownload(generateMacWebloc(currentUrl), 'Vylant.webloc', 'application/octet-stream');
    showDownloadNotice('Downloaded Vylant.webloc shortcut.');
  };

  const handleDownloadIOS = () => {
    triggerFileDownload(generateIOSMobileConfig(currentUrl), 'Vylant.mobileconfig', 'application/x-apple-aspen-config');
    showDownloadNotice('Downloaded Vylant.mobileconfig! Open Settings on iOS to install.');
    onMarkInstalled();
  };

  const handleDownloadAndroidHelper = () => {
    triggerFileDownload(generateAndroidHelperHtml(currentUrl), 'Vylant-Android-Install.html', 'text/html');
    showDownloadNotice('Downloaded Vylant-Android-Install.html.');
    onMarkInstalled();
  };

  const handleDownloadLinuxInstaller = () => {
    triggerFileDownload(generateLinuxInstallerScript(currentUrl), 'vylant-linux-installer.sh', 'application/x-sh');
    showDownloadNotice('Downloaded vylant-linux-installer.sh! Run `bash vylant-linux-installer.sh` in terminal.');
    onMarkInstalled();
  };

  const handleDownloadLinuxDesktop = () => {
    triggerFileDownload(generateLinuxDesktopEntry(currentUrl), 'vylant.desktop', 'application/x-desktop');
    showDownloadNotice('Downloaded vylant.desktop entry.');
    onMarkInstalled();
  };

  const handleDownloadWindows = () => {
    triggerFileDownload(generateWindowsBat(currentUrl), 'Vylant.bat', 'application/x-bat');
    showDownloadNotice('Downloaded Vylant.bat! Run to create Windows desktop app.');
    onMarkInstalled();
  };

  const handleDownloadWindowsUrl = () => {
    triggerFileDownload(generateWindowsUrlShortcut(currentUrl), 'Vylant.url', 'application/octet-stream');
    showDownloadNotice('Downloaded Vylant.url shortcut.');
  };

  const handleNativePrompt = async () => {
    if (installPrompt) {
      try {
        installPrompt.prompt();
        const { outcome } = await installPrompt.userChoice;
        if (outcome === 'accepted') {
          onMarkInstalled();
          onClose();
        }
      } catch (err) {
        console.error('Native install error:', err);
      }
    }
  };

  const linuxTerminalCommand = `curl -sSL "${currentUrl}/api/download/linux" | bash`;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div
        className={`relative w-full max-w-2xl rounded-3xl p-5 sm:p-7 border shadow-2xl flex flex-col gap-5 my-auto max-h-[92vh] overflow-y-auto ${
          isDarkMode
            ? 'bg-[#0f121a] border-white/10 text-white shadow-black/80'
            : 'bg-white border-slate-200 text-slate-900 shadow-slate-300'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close download modal"
          className={`absolute top-4 right-4 p-2.5 rounded-full transition-all z-10 ${
            isDarkMode
              ? 'hover:bg-white/10 text-white/60 hover:text-white'
              : 'hover:bg-slate-100 text-slate-400 hover:text-slate-700'
          }`}
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="flex items-start gap-4 pr-10">
          <div className="relative shrink-0">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden border-2 border-vylant-blue shadow-lg shadow-vylant-blue/20 p-0.5 bg-[#090b10]">
              <img
                src="https://i.imgur.com/H3OS5zA.png"
                alt="Vylant Logo"
                className="w-full h-full object-cover rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-1.5 -right-1.5 bg-vylant-blue text-black p-1 rounded-full shadow-md font-bold">
              <Download size={12} />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">Download Vylant</h2>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-vylant-blue/15 text-vylant-blue border border-vylant-blue/30">
                Cross-Platform
              </span>
            </div>
            <p className={`text-xs sm:text-sm mt-1 leading-relaxed ${isDarkMode ? 'text-white/60' : 'text-slate-500'}`}>
              Install Vylant as a standalone, zero-distraction app on your Mac, iPhone, Android, Linux, or Windows machine.
            </p>
          </div>
        </div>

        {/* Platform Selection Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-black/20 border border-white/5 overflow-x-auto no-scrollbar">
          {PLATFORMS.map((p) => {
            const isSelected = selectedPlatform === p.id;
            return (
              <button
                key={p.id}
                onClick={() => {
                  setSelectedPlatform(p.id);
                  setShowAllPlatforms(false);
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-vylant-blue text-black shadow-md shadow-vylant-blue/20 font-black'
                    : isDarkMode
                    ? 'text-white/70 hover:text-white hover:bg-white/5'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {p.id === 'mac' && <Apple size={15} />}
                {p.id === 'ios' && <Smartphone size={15} />}
                {p.id === 'android' && <Bot size={15} />}
                {p.id === 'linux' && <Terminal size={15} />}
                {p.id === 'windows' && <Laptop size={15} />}
                <span>{p.shortName}</span>
              </button>
            );
          })}
        </div>

        {/* Download Feedback Banner */}
        {downloadFeedback && (
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <Check size={16} className="shrink-0" />
            <span>{downloadFeedback}</span>
          </div>
        )}

        {/* Platform Specific Content */}
        <div className="flex flex-col gap-4">
          {/* ===================== MAC (macOS) TAB ===================== */}
          {selectedPlatform === 'mac' && (
            <div className="flex flex-col gap-4">
              <div
                className={`p-4 sm:p-5 rounded-2xl border flex flex-col gap-3.5 ${
                  isDarkMode ? 'bg-white/[0.03] border-white/10' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-white/10 text-white">
                      <Apple size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold">macOS Standalone App Setup</h3>
                      <p className={`text-xs ${isDarkMode ? 'text-white/50' : 'text-slate-500'}`}>
                        For macOS Sonoma, Sequoia, Ventura & Intel / M1 / M2 / M3 / M4 Macs
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Recommended
                  </span>
                </div>

                <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={handleDownloadMac}
                    className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download size={16} />
                    <span>Download macOS Installer (.command)</span>
                  </button>

                  <button
                    onClick={handleDownloadMacWebloc}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isDarkMode
                        ? 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                        : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                    }`}
                  >
                    <ExternalLink size={15} />
                    <span>Download .webloc Shortcut</span>
                  </button>
                </div>
              </div>

              {/* Safari / Sonoma "Add to Dock" Visual Guide */}
              <div
                className={`p-4 rounded-2xl border text-xs flex flex-col gap-2.5 ${
                  isDarkMode ? 'bg-white/[0.02] border-white/10 text-white/80' : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="font-bold flex items-center gap-2 text-vylant-blue text-xs sm:text-sm">
                  <Sparkles size={15} /> Native macOS Dock App (Safari Sonoma & Sequoia):
                </div>
                <div className="grid sm:grid-cols-3 gap-2.5 pt-1 text-[11px]">
                  <div className={`p-3 rounded-xl border flex flex-col gap-1 ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-white border-slate-200'}`}>
                    <div className="font-bold text-vylant-blue">Step 1</div>
                    <div>Open Vylant in <strong>Safari</strong> on your Mac.</div>
                  </div>
                  <div className={`p-3 rounded-xl border flex flex-col gap-1 ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-white border-slate-200'}`}>
                    <div className="font-bold text-vylant-blue">Step 2</div>
                    <div>Click <strong>File</strong> in the top menu bar &rarr; <strong>Add to Dock...</strong></div>
                  </div>
                  <div className={`p-3 rounded-xl border flex flex-col gap-1 ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-white border-slate-200'}`}>
                    <div className="font-bold text-vylant-blue">Step 3</div>
                    <div>Click <strong>Add</strong>. Launch Vylant directly from your macOS Dock!</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ===================== iOS (iPhone & iPad) TAB ===================== */}
          {selectedPlatform === 'ios' && (
            <div className="flex flex-col gap-4">
              <div
                className={`p-4 sm:p-5 rounded-2xl border flex flex-col gap-3.5 ${
                  isDarkMode ? 'bg-white/[0.03] border-white/10' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
                      <Smartphone size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold">iOS Home Screen App & Profile</h3>
                      <p className={`text-xs ${isDarkMode ? 'text-white/50' : 'text-slate-500'}`}>
                        For iPhone & iPad running iOS 14, 15, 16, 17, 18+
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={handleDownloadIOS}
                    className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download size={16} />
                    <span>Download iOS Profile (.mobileconfig)</span>
                  </button>

                  <button
                    onClick={() => copyToClipboard(currentUrl, 'ios-url')}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isDarkMode
                        ? 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                        : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                    }`}
                  >
                    {copiedKey === 'ios-url' ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
                    <span>{copiedKey === 'ios-url' ? 'URL Copied!' : 'Copy App Link for Safari'}</span>
                  </button>
                </div>
              </div>

              {/* iOS Safari Visual Steps & QR Scan */}
              <div className="grid sm:grid-cols-5 gap-3">
                <div
                  className={`sm:col-span-3 p-4 rounded-2xl border text-xs flex flex-col gap-2 ${
                    isDarkMode ? 'bg-white/[0.02] border-white/10 text-white/80' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5 text-vylant-blue text-xs">
                    <Sparkles size={14} /> 1-Tap Safari Home Screen Setup:
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] leading-relaxed opacity-95">
                    <li>Open <strong>Safari</strong> on your iPhone or iPad.</li>
                    <li>Tap the <strong>Share</strong> button <span className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-[10px]">􀈂</span> (bottom bar).</li>
                    <li>Scroll down and tap <strong>"Add to Home Screen"</strong> <span className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-[10px]">[+]</span>.</li>
                    <li>Tap <strong>Add</strong> in the top-right corner to finish.</li>
                  </ol>
                </div>

                {/* QR Code Container */}
                <div
                  className={`sm:col-span-2 p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-2 ${
                    isDarkMode ? 'bg-white/[0.02] border-white/10' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="text-[11px] font-bold flex items-center gap-1 text-white/70">
                    <QrCode size={13} className="text-vylant-blue" />
                    <span>Scan with iPhone</span>
                  </div>
                  {qrDataUrl ? (
                    <div className="p-1.5 rounded-xl bg-white shadow-md">
                      <img src={qrDataUrl} alt="Vylant iOS QR" className="w-24 h-24 object-contain rounded-lg" />
                    </div>
                  ) : (
                    <div className="w-24 h-24 rounded-xl bg-white/5 animate-pulse" />
                  )}
                  <span className="text-[10px] opacity-60">Open Camera app to scan</span>
                </div>
              </div>
            </div>
          )}

          {/* ===================== ANDROID TAB ===================== */}
          {selectedPlatform === 'android' && (
            <div className="flex flex-col gap-4">
              <div
                className={`p-4 sm:p-5 rounded-2xl border flex flex-col gap-3.5 ${
                  isDarkMode ? 'bg-white/[0.03] border-white/10' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                      <Bot size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold">Android WebAPK & PWA</h3>
                      <p className={`text-xs ${isDarkMode ? 'text-white/50' : 'text-slate-500'}`}>
                        Direct home screen install with hardware acceleration & push notifications
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                  {installPrompt ? (
                    <button
                      onClick={handleNativePrompt}
                      className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download size={16} />
                      <span>Install Vylant Directly (1-Tap)</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleDownloadAndroidHelper}
                      className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download size={16} />
                      <span>Download Android Setup Helper</span>
                    </button>
                  )}

                  <button
                    onClick={() => copyToClipboard(currentUrl, 'android-url')}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isDarkMode
                        ? 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                        : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                    }`}
                  >
                    {copiedKey === 'android-url' ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
                    <span>{copiedKey === 'android-url' ? 'URL Copied!' : 'Copy Android App Link'}</span>
                  </button>
                </div>
              </div>

              {/* Android Instructions & QR Scan */}
              <div className="grid sm:grid-cols-5 gap-3">
                <div
                  className={`sm:col-span-3 p-4 rounded-2xl border text-xs flex flex-col gap-2 ${
                    isDarkMode ? 'bg-white/[0.02] border-white/10 text-white/80' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5 text-vylant-blue text-xs">
                    <Sparkles size={14} /> Android Chrome Quick Install:
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] leading-relaxed opacity-95">
                    <li>Open Vylant in <strong>Google Chrome</strong> or <strong>Samsung Internet</strong>.</li>
                    <li>Tap the <strong>⋮ (three dots)</strong> menu in the upper right.</li>
                    <li>Tap <strong>"Install app"</strong> (or <strong>"Add to Home screen"</strong>).</li>
                    <li>Tap <strong>Install</strong> to confirm.</li>
                  </ol>
                </div>

                <div
                  className={`sm:col-span-2 p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-2 ${
                    isDarkMode ? 'bg-white/[0.02] border-white/10' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="text-[11px] font-bold flex items-center gap-1 text-white/70">
                    <QrCode size={13} className="text-vylant-blue" />
                    <span>Scan with Android</span>
                  </div>
                  {qrDataUrl ? (
                    <div className="p-1.5 rounded-xl bg-white shadow-md">
                      <img src={qrDataUrl} alt="Vylant Android QR" className="w-24 h-24 object-contain rounded-lg" />
                    </div>
                  ) : (
                    <div className="w-24 h-24 rounded-xl bg-white/5 animate-pulse" />
                  )}
                  <span className="text-[10px] opacity-60">Scan with Camera or Lens</span>
                </div>
              </div>
            </div>
          )}

          {/* ===================== LINUX TAB ===================== */}
          {selectedPlatform === 'linux' && (
            <div className="flex flex-col gap-4">
              <div
                className={`p-4 sm:p-5 rounded-2xl border flex flex-col gap-3.5 ${
                  isDarkMode ? 'bg-white/[0.03] border-white/10' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
                      <Terminal size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold">Linux Desktop Package & Launcher</h3>
                      <p className={`text-xs ${isDarkMode ? 'text-white/50' : 'text-slate-500'}`}>
                        For Ubuntu, Debian, Fedora, Arch Linux, Manjaro, Pop!_OS & XDG environments
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={handleDownloadLinuxInstaller}
                    className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download size={16} />
                    <span>Download Installer (vylant-linux-installer.sh)</span>
                  </button>

                  <button
                    onClick={handleDownloadLinuxDesktop}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isDarkMode
                        ? 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                        : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                    }`}
                  >
                    <ExternalLink size={15} />
                    <span>Download vylant.desktop Entry</span>
                  </button>
                </div>
              </div>

              {/* Linux Terminal 1-Liner */}
              <div
                className={`p-4 rounded-2xl border text-xs flex flex-col gap-2.5 ${
                  isDarkMode ? 'bg-white/[0.02] border-white/10 text-white/80' : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold flex items-center gap-1.5 text-vylant-blue text-xs">
                    <Terminal size={14} /> Quick Terminal 1-Liner (curl | bash):
                  </div>
                  <button
                    onClick={() => copyToClipboard(linuxTerminalCommand, 'linux-cmd')}
                    className="flex items-center gap-1 text-[11px] font-bold text-vylant-blue hover:underline cursor-pointer"
                  >
                    {copiedKey === 'linux-cmd' ? (
                      <>
                        <Check size={13} className="text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={13} />
                        <span>Copy Command</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 font-mono text-[11px] text-cyan-300 select-all overflow-x-auto">
                  <code>{linuxTerminalCommand}</code>
                </div>

                <p className="text-[11px] opacity-70">
                  Installs icon to <code className="text-vylant-blue">~/.local/share/icons/vylant.png</code> and adds <code className="text-vylant-blue">~/.local/share/applications/vylant.desktop</code> to your system app menu.
                </p>
              </div>
            </div>
          )}

          {/* ===================== WINDOWS TAB ===================== */}
          {selectedPlatform === 'windows' && (
            <div className="flex flex-col gap-4">
              <div
                className={`p-4 sm:p-5 rounded-2xl border flex flex-col gap-3.5 ${
                  isDarkMode ? 'bg-white/[0.03] border-white/10' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400">
                      <Laptop size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold">Windows Standalone Desktop App</h3>
                      <p className={`text-xs ${isDarkMode ? 'text-white/50' : 'text-slate-500'}`}>
                        For Windows 10 & 11 (Chrome, Edge & Brave chromeless window mode)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    onClick={handleDownloadWindows}
                    className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-vylant-blue hover:bg-cyan-400 text-black shadow-lg shadow-vylant-blue/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download size={16} />
                    <span>Download Windows Launcher (Vylant.bat)</span>
                  </button>

                  <button
                    onClick={handleDownloadWindowsUrl}
                    className={`py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isDarkMode
                        ? 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                        : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                    }`}
                  >
                    <ExternalLink size={15} />
                    <span>Download Vylant.url Shortcut</span>
                  </button>
                </div>
              </div>

              {/* Windows Browser Install Guide */}
              <div
                className={`p-4 rounded-2xl border text-xs flex flex-col gap-2 ${
                  isDarkMode ? 'bg-white/[0.02] border-white/10 text-white/80' : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 text-vylant-blue text-xs">
                  <Sparkles size={14} /> Edge / Chrome Desktop App 1-Click:
                </div>
                <p className="text-[11px] leading-relaxed opacity-90">
                  Open Vylant in <strong>Microsoft Edge</strong> or <strong>Chrome</strong> &rarr; Click the <strong>Install App</strong> icon in the address bar (or Menu &#8942; &gt; Apps &gt; <strong>Install this site as an app</strong>) to pin Vylant to your Taskbar and Start Menu!
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <button
            onClick={() => {
              onMarkInstalled();
              onClose();
            }}
            className={`text-xs font-semibold hover:underline ${
              isDarkMode ? 'text-white/50 hover:text-white/80' : 'text-slate-400 hover:text-slate-700'
            }`}
          >
            Already installed? Don&apos;t show again
          </button>
          <button
            onClick={onClose}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              isDarkMode ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
            }`}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default InstallAppModal;
